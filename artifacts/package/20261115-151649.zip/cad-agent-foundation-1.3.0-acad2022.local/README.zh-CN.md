# CAD Agent Foundation 1.3.0-acad2022.local 运行包

需合法兼容的Windows x64 AutoCAD2022／net48（AutoCAD 2022）桌面运行时及Python3.11+。完整解压后执行foundation.cmd install --acad-year 2022 --workspace C:\CAD-work\demo01，再用start启动来源图的自有副本。默认只读，--write开启有界计划。见docs/QUICKSTART.zh-CN.md及版本验收；新版视图截图与光栅路径修复见docs/FEEDBACK-BETA2-20261023.zh-CN.md；不修改全局MCP，不再分发Autodesk或SHX。
