# CAD Agent Foundation 1.3.0-acad2022.local runtime preview

Windows x64, compatible licensed AutoCAD 2022/net48 (AutoCAD 2022) and Python 3.11+ required.

Install with foundation.cmd install --acad-year 2022 --workspace C:\CAD-work\demo01, then start an owned drawing copy. Default is read-only; use --write for bounded plans. See docs/QUICKSTART.md and docs/PHASE2-DEVELOPMENT-20261015.zh-CN.md for the local 1.2 scope, and docs/DRAWING-UNITS-AND-TYPOGRAPHY.zh-CN.md for raw coordinates, optional unit metadata checks and Agent typography guidance; older public scope remains versioned. Native acceptance is scoped by the versioned release record and manifest. See docs/FEEDBACK-BETA2-20261023.zh-CN.md for the new bounded view/capture and raster path profile. No global MCP changes or Autodesk/SHX redistribution.
