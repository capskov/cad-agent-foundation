# Publication scope

## v1.2.0-local.4 runtime preview

Publishes the native-tested raw-unit closeout runtime with bounded font/phase-two primitives and matching ZIP/MCPB installation assets. The plugin/server/client/support/dependency bytes match the recorded local.4 native run; only documentation, acceptance metadata and outer packaging are finalized for publication. Current and historical validation scopes remain distinct in [the release notes](RELEASE-v1.2.0-local.4.md). Private DWGs, raw journals/receipts, credentials, machine paths, PDBs, Autodesk assemblies and unlicensed SHX are excluded. Earlier tags/assets remain intact; updating GitHub and repository Registry metadata does not itself publish the official Registry.

## v1.1.0-rc.1 runtime preview

The new version adds reviewed native operations and an independently packaged Windows runtime with dependency notices, file hashes and plugin MVID. Its scoped acceptance is recorded in [versioned validation](VALIDATION-v1.1.0-rc.1.md). Private engineering DWGs, journals, credentials, PDBs and Autodesk/SHX redistributions remain excluded. The following section describes the historical source preview only.

## v1.0.0-rc.1 source preview scope

This public release contains source, bilingual usage/compatibility documentation, selected host-free contracts and anonymized display-only case assets. It starts a new clean Git history; private commits, runtime journals, CAD drawings, original engineering receipts and unlicensed SHX assets are excluded.

The accepted local runtime remains v1.0.0-local. Its historical CAD evidence is summarized in VALIDATION.md. The public source snapshot is separately build-checked; it is not a newly certified binary distribution. There is no downloadable runnable binary package in this release. Build/package output is a candidate until its own installation/native checks pass.

Two closed historical pilot files contain illustrative local coordinates instead of original engineering coordinates. Historical native fixtures are omitted. These pilots are outside the supported Foundation CLI/MCP profile and are not public reproducible acceptance datasets. No active FoundationDrawingPlan/Gateway/entry logic is rewritten for publication. Per-file notices and derived package identity changes do not expand support.

Reusable native operations and execution constraints belong in Foundation. Professional scope, classification, styles and placement belong in independent optional Skills. Both reviewed Skill previews are independently public; no automatic Skill installer exists.

The display case shows historical project Python/COM/geometry/planning output, not Foundation-v1-only execution. Exact replay requires cleared CAD inputs and reviewed tools for missing operations; neither is distributed as part of this visual case.
