# ACAD2022 长程自主开发 — 运行状态文件

> 目的：任何一位接手者（人或其他 AI）只读本文件即可知道"做到哪、怎么继续"。
> 权威细节在 `docs/ACAD2022-MIGRATION-STATUS.md`、`docs/ACAD2022-RC1-TEST-LOG.md`、`docs/ACAD2022-RC2-TEST-LOG.md`、`docs/ACAD2022-RC3-TEST-LOG.md`、`docs/technical-reviews/`。

最后更新：2026-11-15 22:0x（Asia/Shanghai）
当前阶段：**RC3 执行中（核心崩溃窗口已闭环，其余项未跑）**
当前运行包：`artifacts/packages/20261115-140318`

## 1. 一句话现状

AutoCAD 2022（net48）移植的写链路（写入 → 验证 → 保存 → finalize）与 callout 已在隔离实例上跑通并有 DWG 落盘证据；本轮补齐"保存成功后、finalize 前崩溃"的跨重启语义：**不自动 finalize、fence 保持、查询立即返回可恢复状态、操作员显式 resolve 才释放**，并修复了一个"重启后查询挂起 120 秒"的真实缺陷。

## 2. 已通过验收

| 节点 | 结论 | 证据 |
|---|---|---|
| RC1 | 通过（五项） | `docs/ACAD2022-RC1-TEST-LOG.md`、`_checkpoints/rc1-final-*` |
| RC2 | 通过（用户认可） | `docs/ACAD2022-RC2-TEST-LOG.md`、`cad2022-test/rc2-b4`、`rc2-callout*` |
| RC3 | 部分（核心窗口闭环） | `docs/ACAD2022-RC3-TEST-LOG.md`、`cad2022-test/rc3-w1` |

RC3 已实测项：
1. 保存成功后崩溃 → 重启 → `dwg_job_get(原 context)` **<1 s** 返回 `recovery_required`（`write_owner_process_changed`，带 `observed_owner_pid` / `current_process_pid`）。
2. 操作员显式 `job_recovery_resolve`（confirm + note）→ `disposition=applied`，fence 删除，journal `write_fence_released=1` + `fence_released_by_operator_after_save`。
3. 保存证据严格绑定：指纹 + 路径 + 时间 + `saved_path` 四项取交集才认账。

## 3. 未完成 / 下一步（按优先级）

P1：
- 重启后 `dwg_job_get` 在已完成 resolve 的情况下仍报 `recovery_required`（保守标签），需要让服务端能从 ledger/journal 感知"fence 已由操作员释放"。
- `save_drawing` 记 `effects=none` 的审计语义（TR-03 第 1 问）。
- 保存失败路径、重复 `request_id`、fence 冲突后人工恢复、控制管道断线的 RC3 重跑。

P2：
- 状态语义全量收敛核对表（五状态 × client/journal/error/next_action）。
- 双实例隔离与超时取消的回归化（RC1 有结论，未重跑）。
- 版本宏与能力宏拆分（`plugin-acad22` 仍借 `ACAD2026` 宏）。

RC4（未开始）：批量 callout、真实工程图副本验证、出图/CTB/PDF、其他 Foundation 能力在 2022 的补齐。
RC5（未开始）：部署/诊断/回退流程、自动化回归入口、2026 编译与静态复核、文档与恢复说明、Git。

外部阻塞：Git 不可用（仅有 SHA256 检查点）；本机无 AutoCAD 2025/2026（2026 无法运行回归）。

## 4. 构建 / 部署 / 测试（可直接照抄）

```
# 编译
dotnet build <fork>\src\plugin-acad22\Bimwright.Dwg.Plugin.Acad22.csproj -c Release
dotnet build <fork>\src\server\Bimwright.Dwg.Server.csproj -c Release
# 打包（年份参数化）
python <main>\scripts\package-runtime.py --acad-year 2022 --version 1.2.0-acad2022.local
# 部署：必须走 client install/start（会话记录 plugin_sha256，手拷 dll 会被拒）
python <pkg>\client\foundation.py start --workspace <ws> --acad-year 2022 --write --allow-save
```

插件必须部署到 `F:\Program Files\Autodesk\AutoCAD 2022\Plugins\CadFoundation2022-*`（受信任区，SECURELOAD 保持开启）。
测试前先 `Get-Process acad`，**只终止非 12948 的实例**（12948 是生产图纸实例，禁止 save/绑定/写入）。

## 5. 关键约束（安全边界，任何接手者不得放宽）

- 不修改生产图纸、不操作用户正在工作的实例、不关闭 SECURELOAD。
- 不清理数据库 / 不删 fence / 不重置任务来"通过测试"。
- 不把未解决办法的崩溃状态自动改判为成功。
- 不推送远程 Git 仓库。
- 保存后崩溃：**不自动 finalize**，保留显式、有审计的人工恢复入口。
- 只有 owner 确认死亡（进程不存在且启动时间不匹配）才允许释放；不确定一律拒绝。

## 6. 最近一次验证的原始命令

```
$env:RC3_PKG='<pkg>'
python cad2022-test\rc3_window.py crash cad2022-test\rc3-w1 cad2022-test\rc2-plan-write.json rc3w cad2022-test\rc3-w1\drawings\rc3w.dwg
python cad2022-test\rc3_window.py after cad2022-test\rc3-w1 rc3w
python cad2022-test\rc3_resolve.py cad2022-test\rc3-w1\native\Dwg\acad-2022.json rc3w
python cad2022-test\dump_journal.py cad2022-test\rc3-w1\native\Dwg\execution\plugin-execution.sqlite
```
